#!/usr/bin/python
import socket

hostname = socket.gethostname()
port = 6633

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

s.bind((hostname, port))
s.listen(5)

print("Listening on " + str(port) + " at " + hostname)

while True:
	clientsocket, address = s.accept()
	print(f"Connection from {address} has been established.")

	msg = input()

	clientsocket.send(bytes(msg, "utf-8"))